package com.example.loginapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
//import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextAlign

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LoginScreen()
        }
    }
}

@Composable
fun LoginScreen() {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    val fondo = Color(0xFF121212)
    val azulIOS = Color(0xFF0A84FF)
    val grisCampo = Color(0xFF1E1E1E)
    val textoGris = Color(0xFFAAAAAA)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(fondo),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .padding(32.dp)
                .fillMaxWidth()
        ) {
            Text(
                text = "Inicia sesión",
                color = Color.White,
                fontSize = 28.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(32.dp))

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Correo electrónico", color = textoGris) },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(grisCampo, shape = RoundedCornerShape(10.dp)),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = grisCampo,
                    focusedContainerColor = grisCampo,
                    unfocusedTextColor = Color.White,
                    focusedTextColor = Color.White,
                    cursorColor = azulIOS,
                    focusedBorderColor = azulIOS,
                    unfocusedBorderColor = textoGris
                ),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Contraseña", color = textoGris) },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier
                    .fillMaxWidth()
                    .background(grisCampo, shape = RoundedCornerShape(10.dp)),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = grisCampo,
                    focusedContainerColor = grisCampo,
                    unfocusedTextColor = Color.White,
                    focusedTextColor = Color.White,
                    cursorColor = azulIOS,
                    focusedBorderColor = azulIOS,
                    unfocusedBorderColor = textoGris
                )
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    println("Email: $email, Password: $password")
                },
                colors = ButtonDefaults.buttonColors(containerColor = azulIOS),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Entrar", color = Color.White, fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "¿No tienes cuenta? Regístrate",
                color = Color(0xFFB0B0B0),
                fontSize = 14.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}
